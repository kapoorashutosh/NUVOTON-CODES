#include "M2354.h"
void SYS_init(void);// system clock decleration

void SYS_init()// system clock defination
{
    SYS_UnlockReg();
	// enabling the clock.
    CLK_EnableXtalRC(CLK_PWRCTL_HIRC48EN_Msk);
	  CLK_EnableXtalRC(CLK_PWRCTL_LIRCEN_Msk); //|CLK_PWRCTL_LXTEN_Msk);{basically for RTC}
    /* Waiting for clock source ready */
    CLK_WaitClockReady(CLK_STATUS_HIRC48STB_Msk);
   	CLK_WaitClockReady(CLK_STATUS_LIRCSTB_Msk); //|CLK_STATUS_LXTSTB_Msk);
	
    CLK_SetCoreClock(96000000);
	
	//clk enable and set module for UART0
	  CLK_EnableModuleClock(UART0_MODULE);
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL2_UART0SEL_PCLK0, CLK_CLKDIV0_UART0(1));

	//clk enable and set RTC clock module
	    CLK_EnableModuleClock(RTC_MODULE);
	    RTC_SetClockSource(RTC_CLOCK_SOURCE_LIRC); //setting the MODULE_APBCLK for lirc clock
	
	//clk enable module for GPIO
	 CLK_EnableModuleClock(GPF_MODULE);
	
	  SystemCoreClockUpdate();
	
	//pin configuration of uart0 on nuvoton board
	 SYS->GPA_MFPL &= ~(SYS_GPA_MFPL_PA7MFP_Msk | SYS_GPA_MFPL_PA6MFP_Msk);
    SYS->GPA_MFPL |= (SYS_GPA_MFPL_PA7MFP_UART0_TXD | SYS_GPA_MFPL_PA6MFP_UART0_RXD);
  
	 // SYS->GPA_MFPL &= ~(SYS_GPA_MFPL_PA7MFP_Msk | SYS_GPA_MFPL_PA6MFP_Msk);
	
	  SYS_LockReg();
	}
