#include "main.h"
#define Push_Button PF11

//char d[7] = {"MONDAY" ,"TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"};
//char *days = d;
// in this function rtcint() we are specifiying some defaul written values to the varables.
void RTC_Init(){
		sInitTime.u32Year       = 2024;
		sInitTime.u32Month      = 11;
		sInitTime.u32Day        = 1;
		sInitTime.u32Hour       = 11;
		sInitTime.u32Minute     = 00;
		sInitTime.u32Second     = 0;
		sInitTime.u32DayOfWeek  = RTC_MONDAY;
		sInitTime.u32TimeScale  = RTC_CLOCK_24;
		if(RTC_Open(&sInitTime) != 0) //this fun writes initial values to the varables and then assignes them to [RTC_GetDateAndTime] this function to set that particular date and time.
		{
		 while(1);
		}
	//	debug_printf("hii rtc is working");
		RTC_SetDate(2024 , 11, 25, RTC_MONDAY); //defined in RTC.c for setting the particular variables as arguments into the function for setting date...
		RTC_SetTime(17,15,00, RTC_CLOCK_24, RTC_AM);   /* Also keep Seconds above 30 */ // aslo defined in rtc.c files for time seconds and all, time scale,stc...
  }

	
// uart function defination 
void UART0_Init() 
{
	UART_Open(UART0, 115200); // defined baud rate
	//uint8_t message[11] = "JAI HANUMAN";
	//UART_Write(UART0, message,sizeof(message));
}

void Peripheral_Init()
{
	UART0_Init();
  GPIO_Init();
	incrementtime_Iint();
}

//funtion for increment of time
void incrementtime_Iint()
{
	sReadRTC.u32Second++;
	if(sReadRTC.u32Second >= 60)
	{
		sReadRTC.u32Second = 0;
		sReadRTC.u32Minute++;
		if(sReadRTC.u32Minute >= 60)
		{
			sReadRTC.u32Minute = 0;
			sReadRTC.u32Hour++;
			if(sReadRTC.u32Hour >= 24)
			{
				sReadRTC.u32Hour = 0;
	
			}
		}
	}
	
	}

	// funtion for GPIO interrupt
	void GPIO_Init()
	{
		
		 GPIO_SetMode(PF,BIT11,GPIO_MODE_INPUT); //it is port F and pin no 11 of push button at P.24
		 GPIO_EnableInt(PF, 11, GPIO_INT_LOW); //port, pin no adnd type of interrupt low because in this its is reverse configuration(i.e o high and 1 low but as we know 0 basically low and 1 is high so)
			NVIC_EnableIRQ(GPF_IRQn);
	}