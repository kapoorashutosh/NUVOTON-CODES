#ifndef __MAIN_H__
#define __MAIN_H__

/** @addtogroup Board library
  @{
*/
#include "M2354.h"

#include "NuMicro.h"
/** @addtogroup Standard libraries , here some of the uncluded libraries are required for the functions used in Debugprint file
  @{
*/
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdbool.h>
#include <float.h>
#include <stdlib.h>

// library of the required board files

#include <stdio.h>
#include "NuMicro.h"
#include "clk.h"
#include "uart.h"
#include "gpio.h"
#include "sys.h"
#include "rtc.h"


//declaration of the extern variables
extern uint8_t RTCFlag ; //this wont be required for this program but could be required incase we are even defining events to the variables could be in case of logic building

 //structure variable declaration
extern S_RTC_TIME_DATA_T sInitTime, sReadRTC;

//declaring some funcvtion for RTC
// inside this function we will be writing or assigning some default values to yyear trime, etc variables
void RTC_Init(void); //initiallisation of RTC function
 
void UART0_Init(void);// uart  function declaration / initialization
//void UART0IT_Init(void);// uart  function declaration / initialization
void Peripheral_Init(void);
void incrementtime_Iint(void);
// funtion for GPIO
	void GPIO_Init(void);

#endif
