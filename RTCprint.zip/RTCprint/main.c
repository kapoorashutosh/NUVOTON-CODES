//including the main.h file
#include "main.h"
#define Push_Button PF11
//initialization of global variables

//char d[7] = {"MONDAY" ,"TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"};
uint8_t RTCFlag = 0;
S_RTC_TIME_DATA_T sInitTime, sReadRTC;

void GPF_IRQHandler(void)
{
		RTC_Init();
}

int main()
{
	SYS_init();
	Peripheral_Init();
	Push_Button = 0; //High
	//debug_printf("hii im ashutosh");
	while(1)
	{
		RTC_GetDateAndTime(&sReadRTC); // This API is used to get the current RTC date and time value.(built in funtion defined in rtc.c file
	debug_printf(" %d/%02d/%02d %02d:%02d:%02d\n ", sReadRTC.u32Year, sReadRTC.u32Month, sReadRTC.u32Day, sReadRTC.u32Hour, sReadRTC.u32Minute, sReadRTC.u32Second);
  incrementtime_Iint();
		 //GPIO_Init();
				CLK_SysTickDelay(200000000000000000);
	}
		
}