#include "main.h"


/**@brief printf function **/
void vprint(const char *fmt,va_list argp){
char string[512];
if(0<vsprintf(string,fmt,argp)){
	
//if(DeveloperModeEnable == 1)
	UART_Write(UART0,(uint8_t*)string,strlen(string));
//else
	//UART_Write(UART5,(uint8_t*)string,strlen(string));
}
}

void debug_printf(const char *fmt, ...){
va_list argp;
va_start(argp,fmt);
vprint(fmt,argp);
va_end(argp);
}
void print_array(uint8_t* input_array, uint32_t array_size, char* comment, uint8_t comment_size)
{
	debug_printf("\r\n");
	for(int i=0;i<comment_size;i++)
	{
		debug_printf("%c",comment[i]);
	}
	debug_printf("\r\n");
	for(int i=0;i<array_size;i++)
	{
		debug_printf("%02X",input_array[i]);
	}
	debug_printf("\r\n");
}