/****************************************************************************
 * @file     nutool_clkcfg.h
 * @version  V1.09.0002
 * @Date     Mon Dec 02 2024 15:49:46 GMT+0530 (India Standard Time)
 * @brief    NuMicro generated code file
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright (C) 2013-2024 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#ifndef __NUTOOL_CLKCFG_H__
#define __NUTOOL_CLKCFG_H__

#ifdef __cplusplus
extern "C"
{
#endif
#ifdef __cplusplus
}
#endif
#endif /*__NUTOOL_CLKCFG_H__*/

/*** (C) COPYRIGHT 2013-2024 Nuvoton Technology Corp. ***/
