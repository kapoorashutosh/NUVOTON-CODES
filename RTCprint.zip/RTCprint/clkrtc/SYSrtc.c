/****************************************************************************
 * @file     SYSrtc.c
 * @version  V1.09.0002
 * @Date     Mon Dec 02 2024 15:49:46 GMT+0530 (India Standard Time)
 * @brief    NuMicro generated code file
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright (C) 2013-2024 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

/********************
MCU:M2354KJFAE(LQFP128)
Base Clocks:
LIRC:10kHz
LXT:32.768kHz
HCLK:32.768kHz
PCLK0:32.768kHz
PCLK1:32.768kHz
Enabled-Module Frequencies:
EWDT=Bus Clock(PCLK0):32.768kHz/Engine Clock:10kHz
EWWDT=Bus Clock(PCLK0):32.768kHz/Engine Clock:16Hz
RTC=Bus Clock(PCLK0):32.768kHz/Engine Clock:32.768kHz
SRAM0=Bus Clock(HCLK):32.768kHz
WDT=Bus Clock(PCLK0):32.768kHz/Engine Clock:10kHz
WWDT=Bus Clock(PCLK0):32.768kHz/Engine Clock:16Hz
********************/

#include "M2354.h"

void SYSrtc_init_ewdt(void)
{
    CLK_EnableModuleClock(EWDT_MODULE);
    CLK_SetModuleClock(EWDT_MODULE, CLK_CLKSEL1_EWDTSEL_LIRC, MODULE_NoMsk);

    return;
}

void SYSrtc_deinit_ewdt(void)
{
    CLK_DisableModuleClock(EWDT_MODULE);

    return;
}

void SYSrtc_init_ewwdt(void)
{
    CLK_EnableModuleClock(EWWDT_MODULE);
    CLK_SetModuleClock(EWWDT_MODULE, CLK_CLKSEL1_EWWDTSEL_HCLK_DIV2048, MODULE_NoMsk);

    return;
}

void SYSrtc_deinit_ewwdt(void)
{
    CLK_DisableModuleClock(EWWDT_MODULE);

    return;
}

void SYSrtc_init_rtc(void)
{
    CLK_EnableModuleClock(RTC_MODULE);
    RTC->LXTCTL = RTC->LXTCTL & ~RTC_LXTCTL_RTCCKSEL_Msk;

    return;
}

void SYSrtc_deinit_rtc(void)
{
    CLK_DisableModuleClock(RTC_MODULE);

    return;
}

void SYSrtc_init_sram0(void)
{
    CLK_EnableModuleClock(SRAM0_MODULE);

    return;
}

void SYSrtc_deinit_sram0(void)
{
    CLK_DisableModuleClock(SRAM0_MODULE);

    return;
}

void SYSrtc_init_wdt(void)
{
    CLK_EnableModuleClock(WDT_MODULE);
    CLK_SetModuleClock(WDT_MODULE, CLK_CLKSEL1_WDTSEL_LIRC, MODULE_NoMsk);

    return;
}

void SYSrtc_deinit_wdt(void)
{
    CLK_DisableModuleClock(WDT_MODULE);

    return;
}

void SYSrtc_init_wwdt(void)
{
    CLK_EnableModuleClock(WWDT_MODULE);
    CLK_SetModuleClock(WWDT_MODULE, CLK_CLKSEL1_WWDTSEL_HCLK_DIV2048, MODULE_NoMsk);

    return;
}

void SYSrtc_deinit_wwdt(void)
{
    CLK_DisableModuleClock(WWDT_MODULE);

    return;
}

void SYSrtc_init_base(void)
{
    /* If the macros do not exist in your project, please refer to the related clk.h in Header folder of the tool package */
    /* LXT source from external LXT */
    CLK_EnableModuleClock(RTC_MODULE);
    RTC->LXTCTL &= ~(RTC_LXTCTL_LIRC32KEN_Msk|RTC_LXTCTL_C32KSEL_Msk);
    CLK_DisableModuleClock(RTC_MODULE);

    /* Enable clock source */
    CLK_EnableXtalRC(CLK_PWRCTL_LIRCEN_Msk|CLK_PWRCTL_LXTEN_Msk);

    /* Waiting for clock source ready */
    CLK_WaitClockReady(CLK_STATUS_LIRCSTB_Msk|CLK_STATUS_LXTSTB_Msk);

    /* Set HCLK clock */
    CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_LXT, CLK_CLKDIV0_HCLK(1));

    return;
}

void SYSrtc_init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    //RTC->LXTCTL   = (RTC->LXTCTL   & ~(0x000000C1UL)) | 0x0000000EUL;
    //CLK->PWRCTL   = (CLK->PWRCTL   & ~(0x0034000FUL)) | 0x0000000AUL;
    //CLK->PLLCTL   = (CLK->PLLCTL   & ~(0x000BFFFFUL)) | 0x0009440AUL;
    //CLK->CLKDIV0  = (CLK->CLKDIV0  & ~(0xFFFFFFFFUL)) | 0x00000000UL;
    //CLK->CLKDIV1  = (CLK->CLKDIV1  & ~(0x00FFFFFFUL)) | 0x00000000UL;
    //CLK->CLKDIV4  = (CLK->CLKDIV4  & ~(0x0000FFFFUL)) | 0x00000000UL;
    //CLK->CLKSEL0  = (CLK->CLKSEL0  & ~(0x0030013FUL)) | 0x00200119UL;
    //CLK->CLKSEL1  = (CLK->CLKSEL1  & ~(0xF07777FFUL)) | 0xA02222B3UL;
    //CLK->CLKSEL2  = (CLK->CLKSEL2  & ~(0x77773FFFUL)) | 0x44442BABUL;
    //CLK->CLKSEL3  = (CLK->CLKSEL3  & ~(0x7703773FUL)) | 0x4402222AUL;
    //CLK->AHBCLK   = (CLK->AHBCLK   & ~(0xFF71F0DFUL)) | 0x00100000UL;
    //CLK->APBCLK0  = (CLK->APBCLK0  & ~(0xBD7FF7FFUL)) | 0x80000003UL;
    //CLK->APBCLK1  = (CLK->APBCLK1  & ~(0x1FCF1377UL)) | 0x00000000UL;
    //CLK->CLKOCTL  = (CLK->CLKOCTL  & ~(0x0000007FUL)) | 0x00000000UL;
    //SysTick->CTRL = (SysTick->CTRL & ~(0x00000005UL)) | 0x00000000UL;

    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Enable base clock */
    SYSrtc_init_base();

    /* Enable module clock and set clock source */
    SYSrtc_init_ewdt();
    SYSrtc_init_ewwdt();
    SYSrtc_init_rtc();
    SYSrtc_init_sram0();
    SYSrtc_init_wdt();
    SYSrtc_init_wwdt();

    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    /* Lock protected registers */
    SYS_LockReg();

    return;
}

/*** (C) COPYRIGHT 2013-2024 Nuvoton Technology Corp. ***/
