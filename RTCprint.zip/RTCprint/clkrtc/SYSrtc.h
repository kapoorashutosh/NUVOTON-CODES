/****************************************************************************
 * @file     SYSrtc.h
 * @version  V1.09.0002
 * @Date     Mon Dec 02 2024 15:49:46 GMT+0530 (India Standard Time)
 * @brief    NuMicro generated code file
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright (C) 2013-2024 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#ifndef __SYSRTC_H__
#define __SYSRTC_H__

#ifdef __cplusplus
extern "C"
{
#endif
void SYSrtc_init_ewdt(void);
void SYSrtc_deinit_ewdt(void);
void SYSrtc_init_ewwdt(void);
void SYSrtc_deinit_ewwdt(void);
void SYSrtc_init_rtc(void);
void SYSrtc_deinit_rtc(void);
void SYSrtc_init_sram0(void);
void SYSrtc_deinit_sram0(void);
void SYSrtc_init_wdt(void);
void SYSrtc_deinit_wdt(void);
void SYSrtc_init_wwdt(void);
void SYSrtc_deinit_wwdt(void);
void SYSrtc_init_base(void);
void SYSrtc_init(void);
#ifdef __cplusplus
}
#endif
#endif /*__SYSRTC_H__*/

/*** (C) COPYRIGHT 2013-2024 Nuvoton Technology Corp. ***/
