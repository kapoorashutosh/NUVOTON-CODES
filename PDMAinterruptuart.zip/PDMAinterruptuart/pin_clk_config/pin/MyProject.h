/****************************************************************************
 * @file     MyProject.h
 * @version  V1.32.0001
 * @Date     Fri Aug 23 2024 17:05:33 GMT+0530 (India Standard Time)
 * @brief    NuMicro generated code file
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright (C) 2013-2024 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#ifndef __MYPROJECT_H__
#define __MYPROJECT_H__

#ifdef __cplusplus
extern "C"
{
#endif
void MyProject_init_ice(void);
void MyProject_deinit_ice(void);
void MyProject_init_pd(void);
void MyProject_deinit_pd(void);
void MyProject_init_pf(void);
void MyProject_deinit_pf(void);
void MyProject_init_uart1(void);
void MyProject_deinit_uart1(void);
void MyProject_init(void);
void MyProject_deinit(void);
#ifdef __cplusplus
}
#endif
#endif /*__MYPROJECT_H__*/

/*** (C) COPYRIGHT 2013-2024 Nuvoton Technology Corp. ***/
