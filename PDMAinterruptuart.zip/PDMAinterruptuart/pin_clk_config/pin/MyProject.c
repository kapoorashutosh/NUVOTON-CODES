/****************************************************************************
 * @file     MyProject.c
 * @version  V1.32.0001
 * @Date     Fri Aug 23 2024 17:05:33 GMT+0530 (India Standard Time)
 * @brief    NuMicro generated code file
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright (C) 2013-2024 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

/********************
MCU:M2354KJFAE(LQFP128)
********************/

#include "M2354.h"

void MyProject_init_ice(void)
{
    SYS->GPF_MFPL &= ~(SYS_GPF_MFPL_PF1MFP_Msk | SYS_GPF_MFPL_PF0MFP_Msk);
    SYS->GPF_MFPL |= (SYS_GPF_MFPL_PF1MFP_ICE_CLK | SYS_GPF_MFPL_PF0MFP_ICE_DAT);

    return;
}

void MyProject_deinit_ice(void)
{
    SYS->GPF_MFPL &= ~(SYS_GPF_MFPL_PF1MFP_Msk | SYS_GPF_MFPL_PF0MFP_Msk);

    return;
}

void MyProject_init_pd(void)
{
    SYS->GPD_MFPL &= ~(SYS_GPD_MFPL_PD3MFP_Msk | SYS_GPD_MFPL_PD2MFP_Msk);
    SYS->GPD_MFPL |= (SYS_GPD_MFPL_PD3MFP_GPIO | SYS_GPD_MFPL_PD2MFP_GPIO);

    return;
}

void MyProject_deinit_pd(void)
{
    SYS->GPD_MFPL &= ~(SYS_GPD_MFPL_PD3MFP_Msk | SYS_GPD_MFPL_PD2MFP_Msk);

    return;
}

void MyProject_init_pf(void)
{
    SYS->GPF_MFPH &= ~(SYS_GPF_MFPH_PF11MFP_Msk);
    SYS->GPF_MFPH |= (SYS_GPF_MFPH_PF11MFP_GPIO);

    return;
}

void MyProject_deinit_pf(void)
{
    SYS->GPF_MFPH &= ~(SYS_GPF_MFPH_PF11MFP_Msk);

    return;
}

void MyProject_init_uart1(void)
{
    SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB3MFP_Msk | SYS_GPB_MFPL_PB2MFP_Msk);
    SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB3MFP_UART1_TXD | SYS_GPB_MFPL_PB2MFP_UART1_RXD);

    return;
}

void MyProject_deinit_uart1(void)
{
    SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB3MFP_Msk | SYS_GPB_MFPL_PB2MFP_Msk);

    return;
}

void MyProject_init(void)
{
    //SYS->GPA_MFPH = 0x00000000UL;
    //SYS->GPA_MFPL = 0x00000000UL;
    //SYS->GPB_MFPH = 0x00000000UL;
    //SYS->GPB_MFPL = 0x00006600UL;
    //SYS->GPC_MFPH = 0x00000000UL;
    //SYS->GPC_MFPL = 0x00000000UL;
    //SYS->GPD_MFPH = 0x00000000UL;
    //SYS->GPD_MFPL = 0x00000000UL;
    //SYS->GPE_MFPH = 0x00000000UL;
    //SYS->GPE_MFPL = 0x00000000UL;
    //SYS->GPF_MFPH = 0x00000000UL;
    //SYS->GPF_MFPL = 0x000000EEUL;
    //SYS->GPG_MFPH = 0x00000000UL;
    //SYS->GPG_MFPL = 0x00000000UL;
    //SYS->GPH_MFPH = 0x00000000UL;
    //SYS->GPH_MFPL = 0x00000000UL;

    MyProject_init_ice();
    MyProject_init_pd();
    MyProject_init_pf();
    MyProject_init_uart1();

    return;
}

void MyProject_deinit(void)
{
    MyProject_deinit_ice();
    MyProject_deinit_pd();
    MyProject_deinit_pf();
    MyProject_deinit_uart1();

    return;
}

/*** (C) COPYRIGHT 2013-2024 Nuvoton Technology Corp. ***/
