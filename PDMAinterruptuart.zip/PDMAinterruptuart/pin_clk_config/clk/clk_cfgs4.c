/****************************************************************************
 * @file     clk_cfgs4.c
 * @version  V1.09.0002
 * @Date     Fri Aug 23 2024 16:56:53 GMT+0530 (India Standard Time)
 * @brief    NuMicro generated code file
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright (C) 2013-2024 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

/********************
MCU:M2354KJFAE(LQFP128)
Base Clocks:
HIRC:12MHz
HCLK:12MHz
PCLK0:12MHz
PCLK1:12MHz
Enabled-Module Frequencies:
FMCIDLE=Bus Clock(HCLK):12MHz/Engine Clock:12MHz
GPD=Bus Clock(HCLK):12MHz
GPF=Bus Clock(HCLK):12MHz
SRAM0=Bus Clock(HCLK):12MHz
UART1=Bus Clock(PCLK1):12MHz/Engine Clock:12MHz
********************/

#include "M2354.h"

void clk_cfgs4_init_fmcidle(void)
{
    CLK_EnableModuleClock(FMCIDLE_MODULE);

    return;
}

void clk_cfgs4_deinit_fmcidle(void)
{
    CLK_DisableModuleClock(FMCIDLE_MODULE);

    return;
}

void clk_cfgs4_init_gpd(void)
{
    CLK_EnableModuleClock(GPD_MODULE);

    return;
}

void clk_cfgs4_deinit_gpd(void)
{
    CLK_DisableModuleClock(GPD_MODULE);

    return;
}

void clk_cfgs4_init_gpf(void)
{
    CLK_EnableModuleClock(GPF_MODULE);

    return;
}

void clk_cfgs4_deinit_gpf(void)
{
    CLK_DisableModuleClock(GPF_MODULE);

    return;
}

void clk_cfgs4_init_sram0(void)
{
    CLK_EnableModuleClock(SRAM0_MODULE);

    return;
}

void clk_cfgs4_deinit_sram0(void)
{
    CLK_DisableModuleClock(SRAM0_MODULE);

    return;
}

void clk_cfgs4_init_uart1(void)
{
    CLK_EnableModuleClock(UART1_MODULE);
    CLK_SetModuleClock(UART1_MODULE, CLK_CLKSEL2_UART1SEL_PCLK1, CLK_CLKDIV0_UART1(1));

    return;
}

void clk_cfgs4_deinit_uart1(void)
{
    CLK_DisableModuleClock(UART1_MODULE);

    return;
}

void clk_cfgs4_init_base(void)
{
    /* If the macros do not exist in your project, please refer to the related clk.h in Header folder of the tool package */
    /* Enable clock source */
    CLK_EnableXtalRC(CLK_PWRCTL_HIRCEN_Msk);

    /* Waiting for clock source ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);

    /* Set HCLK clock */
    CLK_SetHCLK(CLK_CLKSEL0_HCLKSEL_HIRC, CLK_CLKDIV0_HCLK(1));

    return;
}

void clk_cfgs4_init(void)
{
    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/
    //RTC->LXTCTL   = (RTC->LXTCTL   & ~(0x000000C1UL)) | 0x0000000EUL;
    //CLK->PWRCTL   = (CLK->PWRCTL   & ~(0x0034000FUL)) | 0x00000004UL;
    //CLK->PLLCTL   = (CLK->PLLCTL   & ~(0x000BFFFFUL)) | 0x0009440AUL;
    //CLK->CLKDIV0  = (CLK->CLKDIV0  & ~(0xFFFFFFFFUL)) | 0x00000000UL;
    //CLK->CLKDIV1  = (CLK->CLKDIV1  & ~(0x00FFFFFFUL)) | 0x00000000UL;
    //CLK->CLKDIV4  = (CLK->CLKDIV4  & ~(0x0000FFFFUL)) | 0x00000000UL;
    //CLK->CLKSEL0  = (CLK->CLKSEL0  & ~(0x0030013FUL)) | 0x0020011FUL;
    //CLK->CLKSEL1  = (CLK->CLKSEL1  & ~(0xF07777FFUL)) | 0xA02222B3UL;
    //CLK->CLKSEL2  = (CLK->CLKSEL2  & ~(0x77773FFFUL)) | 0x44442BABUL;
    //CLK->CLKSEL3  = (CLK->CLKSEL3  & ~(0x7703773FUL)) | 0x4402222AUL;
    //CLK->AHBCLK   = (CLK->AHBCLK   & ~(0xFF71F0DFUL)) | 0x28108000UL;
    //CLK->APBCLK0  = (CLK->APBCLK0  & ~(0xBD7FF7FFUL)) | 0x00020000UL;
    //CLK->APBCLK1  = (CLK->APBCLK1  & ~(0x1FCF1377UL)) | 0x00000000UL;
    //CLK->CLKOCTL  = (CLK->CLKOCTL  & ~(0x0000007FUL)) | 0x00000000UL;
    //SysTick->CTRL = (SysTick->CTRL & ~(0x00000005UL)) | 0x00000000UL;

    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Enable base clock */
    clk_cfgs4_init_base();

    /* Enable module clock and set clock source */
    clk_cfgs4_init_fmcidle();
    clk_cfgs4_init_gpd();
    clk_cfgs4_init_gpf();
    clk_cfgs4_init_sram0();
    clk_cfgs4_init_uart1();

    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    /* Lock protected registers */
    SYS_LockReg();

    return;
}

/*** (C) COPYRIGHT 2013-2024 Nuvoton Technology Corp. ***/
