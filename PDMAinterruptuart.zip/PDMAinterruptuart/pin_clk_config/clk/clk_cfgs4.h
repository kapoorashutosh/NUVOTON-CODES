/****************************************************************************
 * @file     clk_cfgs4.h
 * @version  V1.09.0002
 * @Date     Fri Aug 23 2024 16:56:53 GMT+0530 (India Standard Time)
 * @brief    NuMicro generated code file
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright (C) 2013-2024 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#ifndef __CLK_CFGS4_H__
#define __CLK_CFGS4_H__

#ifdef __cplusplus
extern "C"
{
#endif
void clk_cfgs4_init_fmcidle(void);
void clk_cfgs4_deinit_fmcidle(void);
void clk_cfgs4_init_gpd(void);
void clk_cfgs4_deinit_gpd(void);
void clk_cfgs4_init_gpf(void);
void clk_cfgs4_deinit_gpf(void);
void clk_cfgs4_init_sram0(void);
void clk_cfgs4_deinit_sram0(void);
void clk_cfgs4_init_uart1(void);
void clk_cfgs4_deinit_uart1(void);
void clk_cfgs4_init_base(void);
void clk_cfgs4_init(void);
#ifdef __cplusplus
}
#endif
#endif /*__CLK_CFGS4_H__*/

/*** (C) COPYRIGHT 2013-2024 Nuvoton Technology Corp. ***/
