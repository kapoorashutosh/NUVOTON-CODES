#include "M2354.h"

void SYS_Init(void){
	
	  SYS_UnlockReg();
    CLK_EnableXtalRC(CLK_PWRCTL_HIRCEN_Msk);
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);
   
    CLK_SetCoreClock(96000000);

	  CLK_EnableModuleClock(GPD_MODULE);
	  CLK_EnableModuleClock(GPF_MODULE);
	  CLK_EnableModuleClock(UART1_MODULE);
	  CLK_EnableModuleClock(PDMA0_MODULE);
    CLK_SetModuleClock(UART1_MODULE, CLK_CLKSEL2_UART1SEL_PCLK1, CLK_CLKDIV0_UART1(1));
	
	  SystemCoreClockUpdate();
	
	  SYS->GPB_MFPL &= ~(SYS_GPB_MFPL_PB3MFP_Msk | SYS_GPB_MFPL_PB2MFP_Msk);
    SYS->GPB_MFPL |= (SYS_GPB_MFPL_PB3MFP_UART1_TXD | SYS_GPB_MFPL_PB2MFP_UART1_RXD);

	
	 SYS_LockReg();
	
	return;

}