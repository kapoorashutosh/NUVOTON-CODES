#include "M2354.h"
#define PDMA_TIME 0x200
extern uint8_t g_u8Rx_Buffer[3];

void UART_Init(void)
{
	UART_Open(UART1, 115200);
	UART_PDMA_ENABLE(UART1, UART_INTEN_RXPDMAEN_Msk);
}
void GPIO_Init(void)
{
	 GPIO_SetMode(PD,BIT2|BIT3,GPIO_MODE_OUTPUT);
	 GPIO_SetMode(PF,BIT11,GPIO_MODE_INPUT);
	 PD2= 1;
    PD3 = 1;
	 CLK_SysTickLongDelay(1000000);
	 PD1 = 0;
	 PD2 = 0;
	 GPIO_EnableInt(PF, 7, GPIO_INT_LOW);
	
}
void PDMA_Init(void)
{
		PDMA_Open(PDMA0, 1 << 1);
		PDMA_SetTransferMode(PDMA0, 1, PDMA_UART1_RX, 0, 0);
		PDMA_SetTransferCnt(PDMA0, 1, PDMA_WIDTH_8, 1024);
		PDMA_SetTransferAddr(PDMA0, 1, UART1_BASE, PDMA_SAR_FIX, ((uint32_t)(&g_u8Rx_Buffer[0])), PDMA_DAR_INC);
		PDMA_SetBurstType(PDMA0, 1, PDMA_REQ_SINGLE, 0);
		PDMA_SetTimeOut(PDMA0, 1, 1, PDMA_TIME);
		
		
		PDMA_EnableInt(PDMA0, 1, PDMA_INT_TIMEOUT);
		NVIC_EnableIRQ(PDMA0_IRQn);
}
void Peripheral_Init(void)
{
	UART_Init();
	GPIO_Init();
	PDMA_Init();
}