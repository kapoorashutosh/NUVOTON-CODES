/****************************************************************************
 * @file     UART0.h
 * @version  V1.33.0003
 * @Date     Tue Nov 26 2024 14:56:54 GMT+0530 (India Standard Time)
 * @brief    NuMicro generated code file
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Copyright (C) 2013-2024 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/

#ifndef __UART0_H__
#define __UART0_H__

#ifdef __cplusplus
extern "C"
{
#endif
void UART0_init_uart0(void);
void UART0_deinit_uart0(void);
void UART0_init(void);
void UART0_deinit(void);
#ifdef __cplusplus
}
#endif
#endif /*__UART0_H__*/

/*** (C) COPYRIGHT 2013-2024 Nuvoton Technology Corp. ***/
