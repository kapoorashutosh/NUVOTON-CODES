#include <stdio.h>
#include "NuMicro.h"
#include "clk.h"
#include "gpio.h"
#include "sys.h"
uint8_t g_u8Rx_Buffer[3] = {0};
/**@brief common buffers **/



uint8_t UART1_FLAG = 0;



///// printf doesn't work  


void PDMA0_IRQHandler(void)
{
	PDMA_SetTimeOut(PDMA0, 1, 0, 0);
	PDMA_CLR_TMOUT_FLAG(PDMA0, 1); // clear interrupt msk.
	UART1_FLAG=1;

}
int main()
{
	  SYS_Init();
	  Peripheral_Init();
    while (1) {
        if (UART1_FLAG == 1) {
            UART1_FLAG = 0;
            char input_char = g_u8Rx_Buffer[0]; 

            if (input_char == 'y') {
                char response[] = "yes";
                UART_Write(UART1, (uint8_t *)response, strlen(response));
            } else if (input_char == 'n') {
                char response[] = "no";
                UART_Write(UART1, (uint8_t *)response, strlen(response));
            }       
            PDMA_Init();	          
        }
    }
    
    return 0;
}
 