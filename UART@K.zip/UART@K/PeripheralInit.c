//UART for nuvoton
#include <stdio.h>
#include <stdint.h>
#include "NuMicro.h"
#include "clk.h"
#include "uart.h"
#include "gpio.h"
#include "sys.h"


void UART0_Init(void);// uart  function declaration / initialization
//void UART0IT_Init(void);// uart  function declaration / initialization

void UART0_Init() // uart function defination and even have included interrupt in it
{
	UART_Open(UART0, 115200); // defined baud rate
	uint8_t message[11] = "JAI HANUMAN";
	UART_Write(UART0, message,sizeof(message));
	printf("hii hello");
	
	//For UART interrupt commands
	 UART_EnableInt(UART0, UART_INTEN_RXTOIEN_Msk); 
	 NVIC_EnableIRQ(UART0_IRQn);
	//printf("JAI HANUMAN"); //can use printf for uart 0 pin)

	
}

