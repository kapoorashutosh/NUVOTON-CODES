//UART for nuvoton
#include <stdio.h>
#include <stdint.h>
#include "NuMicro.h"
#include "clk.h"
#include "uart.h"
#include "gpio.h"
#include "sys.h"

//void SYS_init(void);// system clock decleration
//void SYS_init(void);
//void UART0_Init(void);// uart  function declaration

//void UART0_Init() // uart function defination and even have included interrupt in it
//{
//	UART_Open(UART0, 115200); // defined baud rate
	//uint8_t message[11] = "JAI HANUMAN";
	//UART_Write(UART0, message,sizeof(message));
	//printf("hii hello");
	
	//printf("JAI HANUMAN"); //can use printf for uart 0 pin)
//}
uint8_t g_u8Rx_Buffer[3] = {0};
uint8_t UART1_FLAG = 0;

void UART0_IRQHandler(void); // initializaTION/ declaration
void UART0_IRQHandler() // we write this function to justify that the interrupt has been handled by us
{
	//UART_CLR_INT_FLAG(UART0, UART_INTSTS_RDAINT_Msk);
	//UART_CLR_INT_FLAG(UART0, UART_INTSTS_RXTOINT_Msk);
	UART1_FLAG=1;
}
	

 int main()
 {
	 SYS_init();
	 UART0_Init();
	 

	 while(1)
	 {
		 //here in this while loop i have wriiten logic for interrupt but for some reason the codes not working.
		 uint8_t receivedData[3];

			  if(UART1_FLAG == 1 )
		 {
			  UART1_FLAG = 0;
			 
       UART_Read(UART0, &receivedData, 3);
			 uint8_t input_char = receivedData[0]; 
			 
				 if(input_char == 'a')
			 {
				 char message[] = "PITAJI";
	       UART_Write(UART0, (uint8_t *)message, strlen(message));
				 //printf(" Pitaji\n");
			// break;
			 }
			 else if(input_char == 'b')
			 {
				 //printf("papaji\n");.
				 char message1[] = "PAPAJI";
	       UART_Write(UART0, (uint8_t *)message1, strlen(message1));
			 }
			 UART0_Init();

		 }
	 }
	 return 0;
 }
 