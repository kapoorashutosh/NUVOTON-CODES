#include "M2354.h"
void SYS_init(void);// system clock decleration

void SYS_init()// ayatem clock defination
{
    SYS_UnlockReg();
	
    CLK_EnableXtalRC(CLK_PWRCTL_HIRC48EN_Msk);
	
    /* Waiting for clock source ready */
    CLK_WaitClockReady(CLK_STATUS_HIRC48STB_Msk);
	
    CLK_SetCoreClock(96000000);
	
	  CLK_EnableModuleClock(UART0_MODULE);
    CLK_SetModuleClock(UART0_MODULE, CLK_CLKSEL2_UART0SEL_PCLK0, CLK_CLKDIV0_UART0(1));

	  SystemCoreClockUpdate();
	
	//pin configuration of uart0 on nuvoton board
	 SYS->GPA_MFPL &= ~(SYS_GPA_MFPL_PA7MFP_Msk | SYS_GPA_MFPL_PA6MFP_Msk);
    SYS->GPA_MFPL |= (SYS_GPA_MFPL_PA7MFP_UART0_TXD | SYS_GPA_MFPL_PA6MFP_UART0_RXD);
  
	 // SYS->GPA_MFPL &= ~(SYS_GPA_MFPL_PA7MFP_Msk | SYS_GPA_MFPL_PA6MFP_Msk);
	
	  SYS_LockReg();
	}
